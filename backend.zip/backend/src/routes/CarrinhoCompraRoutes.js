import express from 'express';
import CarrinhoCompraController from '../controllers/CarrinhoCompraController.js';

const router = express.Router();

router.get('/create', CarrinhoCompraController.createProduct);
router.post('/create', CarrinhoCompraController.createProductPost);
router.post('/remove/:id', CarrinhoCompraController.removeProduct);
router.get('/edit/:id', CarrinhoCompraController.editProduct);
router.post('/edit', CarrinhoCompraController.editProductPost);
router.get('/:id', CarrinhoCompraController.getProduct);
router.get('/', CarrinhoCompraController.showProducts);

export default router;