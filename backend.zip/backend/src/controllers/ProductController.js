import Product from '../models/Product.js';

export default class ProductController {
    static async showProducts(req, res) {
        const page = 'Produtos';
        const iconpage = '/images/icon/find_file.ico';
        const auth = true;

        const products = await Product.find().lean();

        products.forEach((product) => {
            if (product.image == null || product.image === "")
                product.image = 'https://cdn-icons-png.flaticon.com/512/1695/1695213.png';
        });

        res.render('products/all', { products, page, iconpage, auth });
    }

    static async createProduct(req, res) {

        res.render('products/create');
    }

    static async createProductPost(req, res) {
        const name = req.body.name;
        const price = req.body.price;
        const description = req.body.description;
        const image = req.body.image;

        const product = new Product({ name, price, description, image });

        if (product.image == null || product.image === "") {
            product.image = 'https://cdn-icons-png.flaticon.com/512/1695/1695213.png';
        }

        await product.save();

        res.redirect('/');
    }

    // Restante dos métodos...
}
